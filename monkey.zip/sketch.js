
var monkey , monkey_running
var ban ,banImage, obs, obstacleImage
var FoodGroup, obstacleGroup
var score , banG
var ground , gamestate

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  banImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
 
}



function setup() {
  
  monkey = createSprite(70,200,20,50);
  monkey.addAnimation("monkey_running", monkey_running);
  monkey.scale = 0.125
  
  obs = createSprite(500,200,10,10)
  ban = createSprite(500,200,10,10)
  
  ground = createSprite(200,320,400,20)
  
  obstaclesGroup = createGroup();
  banG = createGroup();
  //obs.addImage("obstacleImage",obstacleImage)
  //obs.addImage("obstaceImage",obstaceImage);
  score = 0
  gamestate = 1
  //ban.addImage("banImage",banImage); 
}


function draw() {

  background(180);
  
  if(gamestate == 1){
  
    monkey.collide(ground);
    
    if(keyDown("space")&& monkey.y >= 250) {
      monkey.velocityY = -13;
      score = score + 1
  }
    
  }
  
  spawnObs()
  
  text("Score: "+ score, 300,50);
  
  if(monkey.isTouching(banG)){
    score = score + 1
  }
  
  if(monkey.isTouching(obstaclesGroup)){
    gamestate = 0
    
  }
  
  
  monkey.velocityY = monkey.velocityY + 0.8
  
  
  
  drawSprites();
}

function spawnObs(){
 if (frameCount % (120 - score) === 0){
   
   var obs = createSprite(450,300,10,40);
   obs.velocityX = -(7 + score/10);
   
   obs.scale = 0.15;
   obs.lifetime = 300;
   obs.addImage("obstaceImage",obstaceImage);
   
   var ban = createSprite(450,125,10,40);
   ban.velocityX = -(7 + score/10);
   ban.lifetime = 300;
   ban.addImage("banImage",banImage); 
   ban.scale = 0.125
   
   
   obstaclesGroup.add(obs);
   banG.add(ban);
 }
}



